//
//  Sentiment_ApplicationApp.swift
//  Sentiment Application
//
//  Created by Rahim Abbas on 4/16/23.
//

import SwiftUI

@main
struct Sentiment_ApplicationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
